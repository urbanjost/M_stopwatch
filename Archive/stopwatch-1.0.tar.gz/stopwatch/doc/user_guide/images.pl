# LaTeX2HTML 95.1 (Fri Jan 20 1995)
# Associate image original text (scrambled) with physical files.

$key = q/{_inline}$i^rmth~${_inline}/;
$cached_env_img{$key} ='<IMG  ALIGN=BOTTOM ALT="" SRC="img11.gif">'; 
$key = q/{_inline}$bullet${_inline}/;
$cached_env_img{$key} ='<IMG  ALIGN=BOTTOM ALT="" SRC="img9.gif">'; 
$key = q/{_inline}$(i,j)^rmth${_inline}/;
$cached_env_img{$key} ='<IMG  ALIGN=MIDDLE ALT="" SRC="img12.gif">'; 

1;

