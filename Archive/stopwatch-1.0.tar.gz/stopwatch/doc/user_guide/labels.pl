# LaTeX2HTML 95.1 (Fri Jan 20 1995)
# Associate symbolic labels with physical files.

$external_labels{"refman"} ="$URL/node14.html"; 
$external_labels{"cpusec"} ="$URL/node12.html"; 
$external_labels{"opt"} ="$URL/node9.html"; 

1;

